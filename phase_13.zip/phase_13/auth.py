# auth.py

import uuid


class AuthManager:

    def __init__(self):

        # Current logged user
        self.current_user = None

        # token -> user mapping
        self.sessions = {}

    # =========================
    # GENERATE TOKEN
    # =========================

    def generate_token(

        self,
        username
    ):

        token = str(
            uuid.uuid4()
        )

        self.sessions[token] = username

        return token

    # =========================
    # LOGIN
    # =========================

    def login(

        self,
        user
    ):

        # Save current user
        self.current_user = user

        # Generate token
        token = self.generate_token(
            user
        )

        return token

    # =========================
    # LOGOUT
    # =========================

    def logout(self):

        self.current_user = None

    # =========================
    # REQUIRE LOGIN
    # =========================

    def require_login(self):

        if not self.current_user:

            raise PermissionError(
                "Login required"
            )

    # =========================
    # AUTH TOKEN
    # =========================

    def authenticate_token(

        self,
        token
    ):

        user = self.sessions.get(
            token
        )

        if not user:

            raise PermissionError(
                "Invalid token"
            )

        # Restore current user
        self.current_user = user

        return user

    # =========================
    # REMOVE TOKEN
    # =========================

    def remove_token(

        self,
        token
    ):

        if token in self.sessions:

            del self.sessions[token]

    # =========================
    # CHECK TOKEN
    # =========================

    def token_exists(

        self,
        token
    ):

        return token in self.sessions