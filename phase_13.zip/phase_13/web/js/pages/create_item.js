async function createItem() {

    const title =
        document.getElementById(
            "title"
        ).value;

    const details =
        document.getElementById(
            "details"
        ).value;

    const result =
        await apiRequest(
            "/items",
            "POST",
            {
                title,
                details
            }
        );

    if (result.success) {

        window.location =
            "dashboard.html";

    } else {

        document.getElementById(
            "message"
        ).innerHTML = `
            <div class='error-box'>
                ${result.error.message}
            </div>
        `;
    }
}