const params =
    new URLSearchParams(
        window.location.search
    );

const itemId =
    params.get("id");


async function loadItem() {

    const result =
        await apiRequest(
            `/items/${itemId}`
        );

    document.getElementById(
        "title"
    ).value =
        result.data.title;

    document.getElementById(
        "details"
    ).value =
        result.data.details;
}


async function saveItem() {

    const title =
        document.getElementById(
            "title"
        ).value;

    const details =
        document.getElementById(
            "details"
        ).value;

    const result =
        await apiRequest(
            `/items/${itemId}`,
            "PUT",
            {
                title,
                details
            }
        );

    if (result.success) {

        window.location =
            `item.html?id=${itemId}`;

    } else {

        document.getElementById(
            "message"
        ).innerHTML = `
            <div class='error-box'>
                ${result.error.message}
            </div>
        `;
    }
}

loadItem();