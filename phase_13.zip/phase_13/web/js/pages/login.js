/* ========================= */
/* TAB SWITCH */
/* ========================= */

function showLogin() {

    document
        .getElementById(
            "loginForm"
        )
        .classList.remove(
            "hidden"
        );

    document
        .getElementById(
            "registerForm"
        )
        .classList.add(
            "hidden"
        );

    document
        .getElementById(
            "loginTab"
        )
        .classList.add(
            "active"
        );

    document
        .getElementById(
            "registerTab"
        )
        .classList.remove(
            "active"
        );
}


function showRegister() {

    document
        .getElementById(
            "registerForm"
        )
        .classList.remove(
            "hidden"
        );

    document
        .getElementById(
            "loginForm"
        )
        .classList.add(
            "hidden"
        );

    document
        .getElementById(
            "registerTab"
        )
        .classList.add(
            "active"
        );

    document
        .getElementById(
            "loginTab"
        )
        .classList.remove(
            "active"
        );
}


/* ========================= */
/* LOGIN */
/* ========================= */

async function login() {

    const username =
        document.getElementById(
            "loginUsername"
        ).value;

    const password =
        document.getElementById(
            "loginPassword"
        ).value;

    if (!username || !password) {

        return showMessage(
            "All login fields required",
            true
        );
    }

    showGlobalLoading();

    try {

        const result =
            await apiRequest(
                "/login",
                "POST",
                {
                    username,
                    password
                }
            );

        hideGlobalLoading();

        if (result.success) {

            localStorage.setItem(
                "token",
                result.data.token
            );

            showMessage(
                "Login successful"
            );

            setTimeout(() => {

                window.location =
                    "dashboard.html";

            }, 1000);

        } else {

            showMessage(
                result.error.message,
                true
            );
        }

    } catch (error) {

        hideGlobalLoading();

        showMessage(
            "Server connection failed",
            true
        );
    }
}


/* ========================= */
/* REGISTER */
/* ========================= */

async function register() {

    const username =
        document.getElementById(
            "registerUsername"
        ).value;

    const password =
        document.getElementById(
            "registerPassword"
        ).value;

    const role =
        document.getElementById(
            "registerRole"
        ).value;

    if (!username || !password) {

        return showMessage(
            "All register fields required",
            true
        );
    }

    showGlobalLoading();

    try {

        const result =
            await apiRequest(
                "/register",
                "POST",
                {
                    username,
                    password,
                    role
                }
            );

        hideGlobalLoading();

        if (result.success) {

            showMessage(
                "Registration successful"
            );

            showLogin();

        } else {

            showMessage(
                result.error.message,
                true
            );
        }

    } catch (error) {

        hideGlobalLoading();

        showMessage(
            "Server connection failed",
            true
        );
    }
}


/* ========================= */
/* MESSAGE */
/* ========================= */

function showMessage(
    message,
    isError = false
) {

    document.getElementById(
        "message"
    ).innerHTML = `

        <div class="
            ${
                isError
                ?
                "error-box"
                :
                "success-box"
            }
        ">

            ${message}

        </div>
    `;
}