// web/js/pages/item_details.js

/* ========================= */
/* QUERY PARAMS */
/* ========================= */

const params =

    new URLSearchParams(
        window.location.search
    );

const itemId =
    params.get("id");


/* ========================= */
/* LOAD ITEM DETAILS */
/* ========================= */

async function loadItemDetails() {

    // Invalid URL
    if (!itemId) {

        return renderNotFound(
            "Invalid item ID"
        );
    }

    showGlobalLoading();

    // API request
    const result =

        await apiRequest(
            `/items/${itemId}`
        );

    hideGlobalLoading();

    // Error
    if (!result.success) {

        return renderNotFound(
            result.error.message
        );
    }

    const item =
        result.data;

    renderItem(item);

    renderWorkflowButtons(
        item.state
    );

    loadHistory();
}


/* ========================= */
/* RENDER ITEM */
/* ========================= */

function renderItem(item) {

    document.getElementById(
        "itemCard"
    ).innerHTML = `

        <div class="
            item-header
        ">

            <h1>
                ${item.title}
            </h1>

            <span class="
                badge
                ${item.state}
            ">
                ${item.state}
            </span>

        </div>

        <div class="
            item-body
        ">

            <p>
                ${item.details}
            </p>

        </div>

        <div class="
            item-actions
        ">

            <a href="
                edit.html?id=${item.id}
            ">

                <button>
                    Edit
                </button>

            </a>

            <button
                class="
                    delete-btn
                "
                onclick="
                    deleteItem()
                "
            >

                Delete

            </button>

        </div>
    `;
}


/* ========================= */
/* WORKFLOW BUTTONS */
/* ========================= */

function renderWorkflowButtons(
    state
) {

    const container =

        document.getElementById(
            "workflowButtons"
        );

    if (!container) {

        return;
    }

    container.innerHTML = "";

    // Draft
    if (state === "draft") {

        container.innerHTML += `

            <button
                onclick="
                    changeState(
                        'active'
                    )
                "
            >

                Activate

            </button>
        `;
    }

    // Active
    if (state === "active") {

        container.innerHTML += `

            <button
                onclick="
                    changeState(
                        'blocked'
                    )
                "
            >

                Block

            </button>

            <button
                onclick="
                    changeState(
                        'completed'
                    )
                "
            >

                Complete

            </button>
        `;
    }

    // Blocked
    if (state === "blocked") {

        container.innerHTML += `

            <button
                onclick="
                    changeState(
                        'active'
                    )
                "
            >

                Activate

            </button>
        `;
    }

    // Completed
    if (state === "completed") {

        container.innerHTML += `

            <button
                onclick="
                    changeState(
                        'active'
                    )
                "
            >

                Reopen

            </button>
        `;
    }
}


/* ========================= */
/* DELETE ITEM */
/* ========================= */

async function deleteItem() {

    const confirmDelete =

        confirm(
            "Delete this item?"
        );

    if (!confirmDelete) {

        return;
    }

    showGlobalLoading();

    const result =

        await apiRequest(

            `/items/${itemId}`,

            "DELETE"
        );

    hideGlobalLoading();

    // Success
    if (result.success) {

        showSuccess(
            "Item deleted"
        );

        setTimeout(() => {

            window.location =
                "dashboard.html";

        }, 800);

        return;
    }

    // Error
    showError(
        result.error.message
    );
}


/* ========================= */
/* LOAD HISTORY */
/* ========================= */

async function loadHistory() {

    const result =

        await apiRequest(
            `/items/${itemId}/history`
        );

    const container =

        document.getElementById(
            "historyContainer"
        );

    if (!container) {

        return;
    }

    container.innerHTML = "";

    // Error
    if (!result.success) {

        container.innerHTML = `

            <div class="
                error-box
            ">

                Failed to load history

            </div>
        `;

        return;
    }

    // Empty
    if (
        result.data.length === 0
    ) {

        container.innerHTML = `

            <div class="
                empty-history
            ">

                No workflow history

            </div>
        `;

        return;
    }

    // History cards
    result.data.forEach(row => {

        container.innerHTML += `

            <div class="
                history-card
            ">

                <div class="
                    history-states
                ">

                    <span class="
                        old-state
                    ">

                        ${row.old_state}

                    </span>

                    →

                    <span class="
                        new-state
                    ">

                        ${row.new_state}

                    </span>

                </div>

                <small>

                    ${row.changed_at}

                </small>

            </div>
        `;
    });
}


/* ========================= */
/* CHANGE STATE */
/* ========================= */

async function changeState(
    state
) {

    showGlobalLoading();

    const result =

        await apiRequest(

            `/items/${itemId}/${state}`,

            "POST"
        );

    hideGlobalLoading();

    // Success
    if (result.success) {

        showSuccess(
            "Workflow updated"
        );

        loadItemDetails();

        return;
    }

    // Error
    showError(
        result.error.message
    );
}


/* ========================= */
/* NOT FOUND */
/* ========================= */

function renderNotFound(
    message
) {

    document.body.innerHTML = `

        <div class="
            container
        ">

            <div class="
                error-box
            ">

                ${message}

            </div>

            <br>

            <a href="
                dashboard.html
            ">

                <button>

                    Back to Dashboard

                </button>

            </a>

        </div>
    `;
}


/* ========================= */
/* INITIALIZE */
/* ========================= */

loadItemDetails();