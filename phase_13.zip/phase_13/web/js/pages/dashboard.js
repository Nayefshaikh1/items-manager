// web/js/pages/dashboard.js

/* ========================= */
/* GLOBAL STATE */
/* ========================= */

let currentPage = 1;

const LIMIT = 6;


/* ========================= */
/* LOAD ITEMS */
/* ========================= */

async function loadItems() {

    try {

        showLoading();

        // Filter
        const filter =

            document.getElementById(
                "stateFilter"
            ).value;

        // Search
        const search =

            document.getElementById(
                "searchInput"
            )
            .value
            .toLowerCase();

        // Endpoint
        let endpoint =

            `/items?page=${currentPage}&limit=${LIMIT}`;

        // State filter
        if (filter) {

            endpoint +=
                `&state=${filter}`;
        }

        // API call
        const result =

            await apiRequest(
                endpoint
            );

        hideLoading();

        // Error
        if (!result.success) {

            return showErrorMessage(

                result.error.message
            );
        }

        // Safe parsing
        let items = [];

        if (
            result.data &&
            result.data.items
        ) {

            items =
                result.data.items;
        }

        // Search filter
        if (search) {

            items = items.filter(item => {

                return (

                    item.title
                        .toLowerCase()
                        .includes(search)

                    ||

                    item.details
                        .toLowerCase()
                        .includes(search)
                );
            });
        }

        // Render
        renderItems(items);

        renderPagination(
            items.length
        );

        updateSummary(items);

    } catch (error) {

        console.error(error);

        hideLoading();

        showErrorMessage(
            "Dashboard failed to load"
        );
    }
}


/* ========================= */
/* RENDER ITEMS */
/* ========================= */

function renderItems(items) {

    const container =

        document.getElementById(
            "itemsContainer"
        );

    if (!container) {

        return;
    }

    container.innerHTML = "";

    // Empty state
    if (items.length === 0) {

        document
            .getElementById(
                "emptyState"
            )
            .classList.remove(
                "hidden"
            );

        return;
    }

    document
        .getElementById(
            "emptyState"
        )
        .classList.add(
            "hidden"
        );

    // Cards
    items.forEach(item => {

        container.innerHTML += `

            <div class="card">

                <h3>
                    ${item.title}
                </h3>

                <p>
                    ${item.details}
                </p>

                <span class="
                    badge
                    ${item.state}
                ">
                    ${item.state}
                </span>

                <br><br>

                <a href="
                    item.html?id=${item.id}
                ">

                    <button>
                        View Details
                    </button>

                </a>

            </div>
        `;
    });
}


/* ========================= */
/* PAGINATION */
/* ========================= */

function renderPagination(
    itemCount
) {

    const container =

        document.getElementById(
            "pagination"
        );

    if (!container) {

        return;
    }

    container.innerHTML = "";

    // Prev
    container.innerHTML += `

        <button
            onclick="
                previousPage()
            "
            ${
                currentPage === 1
                ?
                "disabled"
                :
                ""
            }
        >

            Prev

        </button>
    `;

    // Current page
    container.innerHTML += `

        <span class="
            page-number
        ">

            Page ${currentPage}

        </span>
    `;

    // Next
    container.innerHTML += `

        <button
            onclick="
                nextPage(
                    ${itemCount}
                )
            "
            ${
                itemCount < LIMIT
                ?
                "disabled"
                :
                ""
            }
        >

            Next

        </button>
    `;
}


/* ========================= */
/* NEXT PAGE */
/* ========================= */

function nextPage(
    itemCount
) {

    // No more items
    if (itemCount < LIMIT) {

        return;
    }

    currentPage++;

    loadItems();
}


/* ========================= */
/* PREVIOUS PAGE */
/* ========================= */

function previousPage() {

    if (currentPage > 1) {

        currentPage--;

        loadItems();
    }
}


/* ========================= */
/* SUMMARY */
/* ========================= */

function updateSummary(
    items
) {

    const total =
        items.length;

    const draft =
        items.filter(
            i =>
                i.state === "draft"
        ).length;

    const active =
        items.filter(
            i =>
                i.state === "active"
        ).length;

    const blocked =
        items.filter(
            i =>
                i.state === "blocked"
        ).length;

    const completed =
        items.filter(
            i =>
                i.state === "completed"
        ).length;

    document.getElementById(
        "totalCount"
    ).innerText = total;

    document.getElementById(
        "draftCount"
    ).innerText = draft;

    document.getElementById(
        "activeCount"
    ).innerText = active;

    document.getElementById(
        "blockedCount"
    ).innerText = blocked;

    document.getElementById(
        "completedCount"
    ).innerText = completed;
}


/* ========================= */
/* LOADING */
/* ========================= */

function showLoading() {

    const loader =

        document.getElementById(
            "loading"
        );

    if (loader) {

        loader.classList.remove(
            "hidden"
        );
    }
}


function hideLoading() {

    const loader =

        document.getElementById(
            "loading"
        );

    if (loader) {

        loader.classList.add(
            "hidden"
        );
    }
}


/* ========================= */
/* ERROR */
/* ========================= */

function showErrorMessage(
    message
) {

    const container =

        document.getElementById(
            "itemsContainer"
        );

    if (!container) {

        return;
    }

    container.innerHTML = `

        <div class="
            error-box
        ">

            ${message}

        </div>
    `;
}


/* ========================= */
/* EVENTS */
/* ========================= */

const searchInput =

    document.getElementById(
        "searchInput"
    );

if (searchInput) {

    searchInput.addEventListener(

        "input",

        () => {

            currentPage = 1;

            loadItems();
        }
    );
}


const stateFilter =

    document.getElementById(
        "stateFilter"
    );

if (stateFilter) {

    stateFilter.addEventListener(

        "change",

        () => {

            currentPage = 1;

            loadItems();
        }
    );
}


/* ========================= */
/* INITIALIZE */
/* ========================= */

loadItems();